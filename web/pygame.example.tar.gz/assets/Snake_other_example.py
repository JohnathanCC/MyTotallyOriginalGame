
import pygame
import random
import math

pygame.init()

# ============================================================
# SETUP
# ============================================================

SIZE = 640
screen = pygame.display.set_mode((SIZE, SIZE))
pygame.display.set_caption("Cute Snake")

clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 70)
small_font = pygame.font.SysFont(None, 24)

# ============================================================
# COLORS
# ============================================================

WHITE = (245, 245, 245)
BLACK = (25, 25, 25)

GREEN = (90, 200, 100)
DARK_GREEN = (45, 150, 70)

PINK = (255, 150, 190)
DARK_PINK = (220, 90, 140)

BLUE = (80, 170, 240)
DARK_BLUE = (40, 110, 190)

PURPLE = (170, 110, 230)
YELLOW = (255, 215, 70)

ORANGE = (255, 150, 70)
RED = (230, 70, 70)

# ============================================================
# GRID
# ============================================================

GRID = 20
CELL = SIZE // GRID

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# ============================================================
# THEME
# ============================================================

def get_theme(level):

    if level < 10:
        return "classic"
    elif level < 20:
        return "kitty"
    elif level < 30:
        return "ocean"
    elif level < 40:
        return "garden"
    elif level < 50:
        return "space"
    else:
        return "candy"


# ============================================================
# THEME COLORS
# ============================================================

def get_theme_colors(theme):

    if theme == "classic":
        return {
            "background": (220, 245, 220),
            "snake": GREEN,
            "snake_dark": DARK_GREEN,
            "food": RED
        }

    elif theme == "kitty":
        return {
            "background": (255, 225, 240),
            "snake": PINK,
            "snake_dark": DARK_PINK,
            "food": BLUE
        }

    elif theme == "ocean":
        return {
            "background": (180, 225, 245),
            "snake": BLUE,
            "snake_dark": DARK_BLUE,
            "food": YELLOW
        }

    elif theme == "garden":
        return {
            "background": (245, 225, 235),
            "snake": PINK,
            "snake_dark": DARK_PINK,
            "food": RED
        }

    elif theme == "space":
        return {
            "background": (25, 20, 50),
            "snake": PURPLE,
            "snake_dark": (100, 60, 170),
            "food": YELLOW
        }

    else:
        return {
            "background": (255, 230, 190),
            "snake": ORANGE,
            "snake_dark": (220, 110, 40),
            "food": PINK
        }


# ============================================================
# FOOD TYPE
# ============================================================

def get_food_type(level):

    if level < 10:
        return "apple"
    elif level < 20:
        return "fish"
    elif level < 30:
        return "star"
    elif level < 40:
        return "strawberry"
    elif level < 50:
        return "planet"
    else:
        return "candy"


# ============================================================
# CREATE FOOD
# ============================================================

def create_food(snake):

    while True:
        food = (
            random.randrange(GRID),
            random.randrange(GRID)
        )

        if food not in snake:
            return food


# ============================================================
# DRAW FOOD
# ============================================================

def draw_food(food, food_type, color):

    x = food[0] * CELL + CELL // 2
    y = food[1] * CELL + CELL // 2

    if food_type == "apple":

        pygame.draw.circle(
            screen, color, (x, y), CELL // 2 - 3
        )

        pygame.draw.line(
            screen, GREEN, (x, y - 7), (x + 6, y - 13), 3
        )

    elif food_type == "fish":

        pygame.draw.ellipse(
            screen, color, (x - 9, y - 6, 18, 12)
        )

        pygame.draw.polygon(
            screen,
            color,
            [
                (x - 8, y),
                (x - 16, y - 8),
                (x - 16, y + 8)
            ]
        )

        pygame.draw.circle(screen, BLACK, (x + 5, y - 2), 2)

    elif food_type == "star":

        points = []

        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = 9 if i % 2 == 0 else 4

            points.append(
                (
                    x + math.cos(angle) * radius,
                    y + math.sin(angle) * radius
                )
            )

        pygame.draw.polygon(screen, color, points)

    elif food_type == "strawberry":

        pygame.draw.circle(screen, color, (x, y + 2), 9)

        pygame.draw.polygon(
            screen,
            GREEN,
            [
                (x - 7, y - 5),
                (x, y - 12),
                (x + 7, y - 5)
            ]
        )

    elif food_type == "planet":

        pygame.draw.circle(screen, color, (x, y), 8)

        pygame.draw.ellipse(
            screen, WHITE, (x - 12, y - 4, 24, 8), 2
        )

    elif food_type == "candy":

        pygame.draw.rect(
            screen, color, (x - 7, y - 5, 14, 10)
        )

        pygame.draw.polygon(
            screen,
            color,
            [
                (x - 7, y - 5),
                (x - 13, y - 10),
                (x - 13, y),
                (x - 7, y + 5)
            ]
        )

        pygame.draw.polygon(
            screen,
            color,
            [
                (x + 7, y - 5),
                (x + 13, y - 10),
                (x + 13, y),
                (x + 7, y + 5)
            ]
        )


# ============================================================
# DRAW BACKGROUND
# ============================================================

def draw_background(theme):

    colors = get_theme_colors(theme)
    screen.fill(colors["background"])

    if theme == "kitty":

        for y in range(50, SIZE, 110):
            for x in range(50, SIZE, 130):

                pygame.draw.polygon(
                    screen,
                    (255, 190, 215),
                    [
                        (x - 13, y - 8),
                        (x - 6, y - 25),
                        (x + 1, y - 8)
                    ]
                )

                pygame.draw.polygon(
                    screen,
                    (255, 190, 215),
                    [
                        (x + 1, y - 8),
                        (x + 8, y - 25),
                        (x + 15, y - 8)
                    ]
                )

                pygame.draw.circle(
                    screen, (255, 210, 225), (x + 1, y), 16
                )

                pygame.draw.circle(
                    screen, BLACK, (x - 5, y - 2), 2
                )

                pygame.draw.circle(
                    screen, BLACK, (x + 7, y - 2), 2
                )

                pygame.draw.circle(
                    screen, PINK, (x + 1, y + 5), 2
                )

    elif theme == "ocean":

        for y in range(50, SIZE, 80):
            pygame.draw.arc(
                screen,
                (150, 205, 235),
                (0, y, SIZE, 30),
                0,
                math.pi
            )

    elif theme == "garden":

        for y in range(40, SIZE, 100):
            for x in range(40, SIZE, 120):

                pygame.draw.circle(
                    screen, (255, 190, 215), (x, y), 6
                )

                pygame.draw.circle(
                    screen, YELLOW, (x, y), 3
                )

    elif theme == "space":

        random.seed(5)

        for i in range(100):
            x = random.randrange(SIZE)
            y = random.randrange(SIZE)

            pygame.draw.circle(
                screen,
                WHITE,
                (x, y),
                random.choice([1, 1, 2])
            )

        random.seed()


# ============================================================
# DRAW SNAKE
# ============================================================

def draw_snake(snake, theme):

    colors = get_theme_colors(theme)

    if theme == "classic":
        shape = "square"
    elif theme == "kitty":
        shape = "circle"
    elif theme == "ocean":
        shape = "bubble"
    elif theme == "garden":
        shape = "heart"
    elif theme == "space":
        shape = "star"
    else:
        shape = "candy"

    for i, segment in enumerate(snake):

        x = segment[0] * CELL + CELL // 2
        y = segment[1] * CELL + CELL // 2

        color = colors["snake"] if i == 0 else colors["snake_dark"]

        if shape == "square":

            rect = pygame.Rect(
                x - CELL // 2 + 2,
                y - CELL // 2 + 2,
                CELL - 4,
                CELL - 4
            )

            pygame.draw.rect(
                screen, color, rect, border_radius=5
            )

        elif shape == "circle":

            pygame.draw.circle(
                screen, color, (x, y), CELL // 2 - 2
            )

        elif shape == "bubble":

            pygame.draw.circle(
                screen, color, (x, y), CELL // 2 - 2
            )

            pygame.draw.circle(
                screen, WHITE, (x - 4, y - 4), 2
            )

        elif shape == "heart":

            points = [
                (x, y + 8),
                (x - 10, y - 3),
                (x - 8, y - 9),
                (x - 3, y - 11),
                (x, y - 6),
                (x + 3, y - 11),
                (x + 8, y - 9),
                (x + 10, y - 3)
            ]

            pygame.draw.polygon(screen, color, points)

        elif shape == "star":

            points = []

            for j in range(10):
                angle = -math.pi / 2 + j * math.pi / 5
                radius = 10 if j % 2 == 0 else 5

                points.append(
                    (
                        x + math.cos(angle) * radius,
                        y + math.sin(angle) * radius
                    )
                )

            pygame.draw.polygon(screen, color, points)

        elif shape == "candy":

            rect = pygame.Rect(x - 8, y - 6, 16, 12)

            pygame.draw.rect(
                screen, color, rect, border_radius=6
            )

    # Snake eyes

    head = snake[0]

    hx = head[0] * CELL + CELL // 2
    hy = head[1] * CELL + CELL // 2

    pygame.draw.circle(screen, BLACK, (hx - 4, hy - 3), 2)
    pygame.draw.circle(screen, BLACK, (hx + 4, hy - 3), 2)


# ============================================================
# RESET GAME
# ============================================================

def reset_game():

    snake = [
        (10, 10),
        (9, 10),
        (8, 10)
    ]

    direction = RIGHT
    next_direction = RIGHT

    food = create_food(snake)

    score = 0
    level = 1

    game_over = False
    paused = False

    return (
        snake,
        direction,
        next_direction,
        food,
        score,
        level,
        game_over,
        paused
    )


# ============================================================
# START GAME
# ============================================================

(
    snake,
    direction,
    next_direction,
    food,
    score,
    level,
    game_over,
    paused
) = reset_game()

running = True
started = False

high_score = 0

# Stores the time when the level-up message should disappear.
level_message_timer = 0


# ============================================================
# MAIN LOOP
# ============================================================

while running:

    # ========================================================
    # EVENTS
    # ========================================================

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:

            if not started:

                if event.key == pygame.K_SPACE:
                    started = True

                elif event.key == pygame.K_x:
                    running = False

            elif game_over:

                if event.key == pygame.K_r:

                    (
                        snake,
                        direction,
                        next_direction,
                        food,
                        score,
                        level,
                        game_over,
                        paused
                    ) = reset_game()

                    level_message_timer = 0

                elif event.key == pygame.K_x:
                    running = False

            else:

                if event.key == pygame.K_p:
                    paused = not paused

                elif event.key == pygame.K_r:

                    (
                        snake,
                        direction,
                        next_direction,
                        food,
                        score,
                        level,
                        game_over,
                        paused
                    ) = reset_game()

                    level_message_timer = 0

                elif event.key == pygame.K_x:
                    running = False

                # Movement

                if event.key in (pygame.K_UP, pygame.K_w):
                    if direction != DOWN:
                        next_direction = UP

                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    if direction != UP:
                        next_direction = DOWN

                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    if direction != RIGHT:
                        next_direction = LEFT

                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    if direction != LEFT:
                        next_direction = RIGHT

    # ========================================================
    # START SCREEN
    # ========================================================

    if not started:

        draw_background("kitty")

        title = big_font.render(
            "CUTE SNAKE", True, DARK_PINK
        )

        start_text = font.render(
            "Press SPACE to start", True, BLACK
        )

        controls = small_font.render(
            "Arrow Keys / WASD  |  P = Pause", True, BLACK
        )

        screen.blit(
            title,
            title.get_rect(center=(SIZE // 2, 230))
        )

        screen.blit(
            start_text,
            start_text.get_rect(center=(SIZE // 2, 330))
        )

        screen.blit(
            controls,
            controls.get_rect(center=(SIZE // 2, 380))
        )

        pygame.display.flip()
        clock.tick(60)
        continue

    # ========================================================
    # GAME LOGIC
    # ========================================================

    if not game_over and not paused:

        direction = next_direction

        head_x, head_y = snake[0]

        new_head = (
            head_x + direction[0],
            head_y + direction[1]
        )

        # Wall collision

        if (
            new_head[0] < 0
            or new_head[0] >= GRID
            or new_head[1] < 0
            or new_head[1] >= GRID
        ):

            game_over = True

        # Self collision

        elif new_head in snake:

            game_over = True

        else:

            snake.insert(0, new_head)

            # Food

            if new_head == food:

                score += 1

                old_level = level
                level = score + 1

                if score > high_score:
                    high_score = score

                food = create_food(snake)

                # Show level-up message for one second.

                if level != old_level:
                    level_message_timer = (
                        pygame.time.get_ticks() + 1000
                    )

            else:

                snake.pop()

    # ========================================================
    # CURRENT THEME
    # ========================================================

    theme = get_theme(level)
    colors = get_theme_colors(theme)

    # ========================================================
    # DRAW
    # ========================================================

    draw_background(theme)

    food_type = get_food_type(level)

    draw_food(food, food_type, colors["food"])
    draw_snake(snake, theme)

    # ========================================================
    # UI
    # Only Score and Best remain visible.
    # ========================================================

    text_color = WHITE if theme == "space" else BLACK

    score_text = font.render(
        f"Score: {score}",
        True,
        text_color
    )

    best_text = small_font.render(
        f"Best: {high_score}",
        True,
        text_color
    )

    screen.blit(score_text, (10, 10))
    screen.blit(best_text, (SIZE - 80, 12))

    # ========================================================
    # LEVEL-UP MESSAGE
    # Appears briefly at the top-center.
    # ========================================================

    if pygame.time.get_ticks() < level_message_timer:

        level_up = font.render(
            f"LEVEL {level}!",
            True,
            colors["snake"]
        )

        message_rect = level_up.get_rect(
            center=(SIZE // 2, 80)
        )

        message_bg = message_rect.inflate(24, 16)

        pygame.draw.rect(
            screen,
            colors["background"],
            message_bg,
            border_radius=12
        )

        screen.blit(
            level_up,
            level_up.get_rect(center=message_bg.center)
        )

    # ========================================================
    # PAUSED
    # ========================================================

    if paused:

        pause_text = big_font.render(
            "PAUSED", True, YELLOW
        )

        screen.blit(
            pause_text,
            pause_text.get_rect(
                center=(SIZE // 2, SIZE // 2)
            )
        )

    # ========================================================
    # GAME OVER
    # ========================================================

    if game_over:

        overlay = pygame.Surface((SIZE, SIZE))
        overlay.set_alpha(180)
        overlay.fill(BLACK)

        screen.blit(overlay, (0, 0))

        game_over_text = big_font.render(
            "GAME OVER", True, RED
        )

        final_score = font.render(
            f"Score: {score}", True, WHITE
        )

        final_level = font.render(
            f"Level: {level}", True, WHITE
        )

        restart_text = font.render(
            "Press R to restart", True, WHITE
        )

        quit_text = small_font.render(
            "Press X to quit", True, WHITE
        )

        screen.blit(
            game_over_text,
            game_over_text.get_rect(
                center=(SIZE // 2, 210)
            )
        )

        screen.blit(
            final_score,
            final_score.get_rect(
                center=(SIZE // 2, 290)
            )
        )

        screen.blit(
            final_level,
            final_level.get_rect(
                center=(SIZE // 2, 325)
            )
        )

        screen.blit(
            restart_text,
            restart_text.get_rect(
                center=(SIZE // 2, 380)
            )
        )

        screen.blit(
            quit_text,
            quit_text.get_rect(
                center=(SIZE // 2, 425)
            )
        )

    # ========================================================
    # DISPLAY
    # ========================================================

    pygame.display.flip()

    # ========================================================
    # SPEED
    # Starts slowly and gets faster as the level increases.
    # Maximum speed is 15.
    # ========================================================

    speed = min(15, 5 + level * 0.5)

    clock.tick(speed)


pygame.quit()