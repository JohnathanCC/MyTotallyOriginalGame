import pygame
import random
import math
import asyncio # Web browsers require an asynchronous event loop so the tab doesn't freeze.
# python -m pygbag .
import js # Pygbag provides js module for browser interop

# ADDED: Worker URL and Game ID for the leaderboard
API_BASE = "https://my-leaderboard-worker.my-leaderboard-worker.workers.dev"
GAME_ID = "vibe-snake"

pygame.init()

# ============================================================
# SETUP
# ============================================================

SIZE = 640
screen = pygame.display.set_mode((SIZE, SIZE))
pygame.display.set_caption("Cute Snake Leaderboard Game")

clock = pygame.time.Clock()

font = pygame.font.SysFont(None, 32)
big_font = pygame.font.SysFont(None, 70)
small_font = pygame.font.SysFont(None, 24)

# ============================================================
# COLORS
# ============================================================

WHITE = (245, 245, 245)
BLACK = (25, 25, 25)

GREEN = (90, 200, 100)
DARK_GREEN = (45, 150, 70)

PINK = (255, 150, 190)
DARK_PINK = (220, 90, 140)

BLUE = (80, 170, 240)
DARK_BLUE = (40, 110, 190)

PURPLE = (170, 110, 230)
YELLOW = (255, 215, 70)

ORANGE = (255, 150, 70)
RED = (230, 70, 70)

# ============================================================
# GRID
# ============================================================

GRID = 20
CELL = SIZE // GRID

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# ============================================================
# ADDED: ---- Leaderboard state ----
# ============================================================
STATE_START = "start"
STATE_PLAYING = "playing"
STATE_GAMEOVER = "gameover"

game_state = STATE_START
player_name = ""
leaderboard = []         # list of dicts: {"player_name":..., "score":...}
lb_loading = False
lb_submitted = False
lb_error = ""

def fetch_leaderboard_js():
    """Ask JS to GET /scores and store the result in window.__lb_data."""
    js.eval(f"""
        window.__lb_data = null;
        window.__lb_error = null;
        fetch('{API_BASE}/scores?game={GAME_ID}')
          .then(r => r.json())
          .then(d => {{ window.__lb_data = d; }})
          .catch(e => {{ window.__lb_error = String(e); }});
    """)

def submit_score_js(name, sc):
    """Ask JS to POST /score and store success flag in window.__lb_submitted."""
    safe_name = name.replace("\\", "\\\\").replace("'", "\\'")
    js.eval(f"""
        window.__lb_submitted = null;
        fetch('{API_BASE}/score', {{
            method: 'POST',
            headers: {{ 'Content-Type': 'application/json' }},
            body: JSON.stringify({{ game: '{GAME_ID}', name: '{safe_name}', score: {sc} }})
        }})
        .then(r => r.json())
        .then(d => {{ window.__lb_submitted = d.success === true; }})
        .catch(e => {{ window.__lb_submitted = false; }});
    """)

def poll_js_results():
    """Read the JS globals set by the fetch callbacks."""
    global leaderboard, lb_loading, lb_submitted, lb_error
    try:
        data = js.window.__lb_data
        if data is not None:
            leaderboard = [
                {"player_name": str(row["player_name"]), "score": int(row["score"])}
                for row in data
            ]
            lb_loading = False
            js.eval("window.__lb_data = null;")
    except Exception:
        pass

    try:
        err = js.window.__lb_error
        if err is not None:
            lb_error = str(err)
            lb_loading = False
            js.eval("window.__lb_error = null;")
    except Exception:
        pass

    try:
        sub = js.window.__lb_submitted
        if sub is not None:
            lb_submitted = bool(sub)
            js.eval("window.__lb_submitted = null;")
            lb_loading = True
            fetch_leaderboard_js()
    except Exception:
        pass

# ============================================================
# THEME
# ============================================================

def get_theme(level):
    if level < 10:
        return "classic"
    elif level < 20:
        return "kitty"
    elif level < 30:
        return "ocean"
    elif level < 40:
        return "garden"
    elif level < 50:
        return "space"
    else:
        return "candy"

# ============================================================
# THEME COLORS
# ============================================================

def get_theme_colors(theme):
    if theme == "classic":
        return {
            "background": (220, 245, 220),
            "snake": GREEN,
            "snake_dark": DARK_GREEN,
            "food": RED
        }
    elif theme == "kitty":
        return {
            "background": (255, 225, 240),
            "snake": PINK,
            "snake_dark": DARK_PINK,
            "food": BLUE
        }
    elif theme == "ocean":
        return {
            "background": (180, 225, 245),
            "snake": BLUE,
            "snake_dark": DARK_BLUE,
            "food": YELLOW
        }
    elif theme == "garden":
        return {
            "background": (245, 225, 235),
            "snake": PINK,
            "snake_dark": DARK_PINK,
            "food": RED
        }
    elif theme == "space":
        return {
            "background": (25, 20, 50),
            "snake": PURPLE,
            "snake_dark": (100, 60, 170),
            "food": YELLOW
        }
    else:
        return {
            "background": (255, 230, 190),
            "snake": ORANGE,
            "snake_dark": (220, 110, 40),
            "food": PINK
        }

# ============================================================
# FOOD TYPE
# ============================================================

def get_food_type(level):
    if level < 10:
        return "apple"
    elif level < 20:
        return "fish"
    elif level < 30:
        return "star"
    elif level < 40:
        return "strawberry"
    elif level < 50:
        return "planet"
    else:
        return "candy"

# ============================================================
# CREATE FOOD
# ============================================================

def create_food(snake):
    while True:
        food = (
            random.randrange(GRID),
            random.randrange(GRID)
        )
        if food not in snake:
            return food

# ============================================================
# DRAW FOOD
# ============================================================

def draw_food(food, food_type, color):
    x = food[0] * CELL + CELL // 2
    y = food[1] * CELL + CELL // 2

    if food_type == "apple":
        pygame.draw.circle(screen, color, (x, y), CELL // 2 - 3)
        pygame.draw.line(screen, GREEN, (x, y - 7), (x + 6, y - 13), 3)
    elif food_type == "fish":
        pygame.draw.ellipse(screen, color, (x - 9, y - 6, 18, 12))
        pygame.draw.polygon(screen, color, [(x - 8, y), (x - 16, y - 8), (x - 16, y + 8)])
        pygame.draw.circle(screen, BLACK, (x + 5, y - 2), 2)
    elif food_type == "star":
        points = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = 9 if i % 2 == 0 else 4
            points.append((x + math.cos(angle) * radius, y + math.sin(angle) * radius))
        pygame.draw.polygon(screen, color, points)
    elif food_type == "strawberry":
        pygame.draw.circle(screen, color, (x, y + 2), 9)
        pygame.draw.polygon(screen, GREEN, [(x - 7, y - 5), (x, y - 12), (x + 7, y - 5)])
    elif food_type == "planet":
        pygame.draw.circle(screen, color, (x, y), 8)
        pygame.draw.ellipse(screen, WHITE, (x - 12, y - 4, 24, 8), 2)
    elif food_type == "candy":
        pygame.draw.rect(screen, color, (x - 7, y - 5, 14, 10))
        pygame.draw.polygon(screen, color, [(x - 7, y - 5), (x - 13, y - 10), (x - 13, y), (x - 7, y + 5)])
        pygame.draw.polygon(screen, color, [(x + 7, y - 5), (x + 13, y - 10), (x + 13, y), (x + 7, y + 5)])

# ============================================================
# DRAW BACKGROUND
# ============================================================

def draw_background(theme):
    colors = get_theme_colors(theme)
    screen.fill(colors["background"])

    if theme == "kitty":
        for y in range(50, SIZE, 110):
            for x in range(50, SIZE, 130):
                pygame.draw.polygon(screen, (255, 190, 215), [(x - 13, y - 8), (x - 6, y - 25), (x + 1, y - 8)])
                pygame.draw.polygon(screen, (255, 190, 215), [(x + 1, y - 8), (x + 8, y - 25), (x + 15, y - 8)])
                pygame.draw.circle(screen, (255, 210, 225), (x + 1, y), 16)
                pygame.draw.circle(screen, BLACK, (x - 5, y - 2), 2)
                pygame.draw.circle(screen, BLACK, (x + 7, y - 2), 2)
                pygame.draw.circle(screen, PINK, (x + 1, y + 5), 2)
    elif theme == "ocean":
        for y in range(50, SIZE, 80):
            pygame.draw.arc(screen, (150, 205, 235), (0, y, SIZE, 30), 0, math.pi)
    elif theme == "garden":
        for y in range(40, SIZE, 100):
            for x in range(40, SIZE, 120):
                pygame.draw.circle(screen, (255, 190, 215), (x, y), 6)
                pygame.draw.circle(screen, YELLOW, (x, y), 3)
    elif theme == "space":
        random.seed(5)
        for i in range(100):
            x = random.randrange(SIZE)
            y = random.randrange(SIZE)
            pygame.draw.circle(screen, WHITE, (x, y), random.choice([1, 1, 2]))
        random.seed()

# ============================================================
# DRAW SNAKE
# ============================================================

def draw_snake(snake, theme):
    colors = get_theme_colors(theme)

    if theme == "classic":
        shape = "square"
    elif theme == "kitty":
        shape = "circle"
    elif theme == "ocean":
        shape = "bubble"
    elif theme == "garden":
        shape = "heart"
    elif theme == "space":
        shape = "star"
    else:
        shape = "candy"

    for i, segment in enumerate(snake):
        x = segment[0] * CELL + CELL // 2
        y = segment[1] * CELL + CELL // 2
        color = colors["snake"] if i == 0 else colors["snake_dark"]

        if shape == "square":
            rect = pygame.Rect(x - CELL // 2 + 2, y - CELL // 2 + 2, CELL - 4, CELL - 4)
            pygame.draw.rect(screen, color, rect, border_radius=5)
        elif shape == "circle":
            pygame.draw.circle(screen, color, (x, y), CELL // 2 - 2)
        elif shape == "bubble":
            pygame.draw.circle(screen, color, (x, y), CELL // 2 - 2)
            pygame.draw.circle(screen, WHITE, (x - 4, y - 4), 2)
        elif shape == "heart":
            points = [(x, y + 8), (x - 10, y - 3), (x - 8, y - 9), (x - 3, y - 11), (x, y - 6), (x + 3, y - 11), (x + 8, y - 9), (x + 10, y - 3)]
            pygame.draw.polygon(screen, color, points)
        elif shape == "star":
            points = []
            for j in range(10):
                angle = -math.pi / 2 + j * math.pi / 5
                radius = 10 if j % 2 == 0 else 5
                points.append((x + math.cos(angle) * radius, y + math.sin(angle) * radius))
            pygame.draw.polygon(screen, color, points)
        elif shape == "candy":
            rect = pygame.Rect(x - 8, y - 6, 16, 12)
            pygame.draw.rect(screen, color, rect, border_radius=6)

    head = snake[0]
    hx = head[0] * CELL + CELL // 2
    hy = head[1] * CELL + CELL // 2
    pygame.draw.circle(screen, BLACK, (hx - 4, hy - 3), 2)
    pygame.draw.circle(screen, BLACK, (hx + 4, hy - 3), 2)

# ============================================================
# RESET GAME
# ============================================================

def reset_game():
    snake = [(10, 10), (9, 10), (8, 10)]
    direction = RIGHT
    next_direction = RIGHT
    food = create_food(snake)
    score = 0
    level = 1
    paused = False
    return snake, direction, next_direction, food, score, level, paused

# Initialize state variables
snake, direction, next_direction, food, score, level, paused = reset_game()
high_score = 0
level_message_timer = 0

async def main():
    global snake, direction, next_direction, food, score, level, paused
    global high_score, level_message_timer, game_state, player_name
    global leaderboard, lb_loading, lb_submitted, lb_error

    running = True

    while running:
        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    try:
                        js.eval("window.parent.closeGame && window.parent.closeGame();")
                    except Exception:
                        pass

                elif game_state == STATE_START:
                    if event.key == pygame.K_SPACE:
                        game_state = STATE_PLAYING
                    elif event.key == pygame.K_x:
                        running = False
                        try:
                            js.eval("window.parent.closeGame && window.parent.closeGame();")
                        except Exception:
                            pass

                elif game_state == STATE_GAMEOVER:
                    if event.key == pygame.K_BACKSPACE:
                        player_name = player_name[:-1]
                    elif event.key == pygame.K_RETURN:
                        if player_name.strip() and not lb_submitted:
                            lb_submitted = True # Set it to True to prevent double-submits
                            submit_score_js(player_name.strip()[:16], score)
                    elif event.key == pygame.K_r and (lb_submitted or not player_name):
                        snake, direction, next_direction, food, score, level, paused = reset_game()
                        level_message_timer = 0
                        game_state = STATE_PLAYING
                        player_name = ""
                        leaderboard = []
                        lb_loading = False
                        lb_submitted = False
                        lb_error = ""
                    elif event.unicode.isprintable() and len(player_name) < 16:
                        player_name += event.unicode

                else: # STATE_PLAYING
                    if event.key == pygame.K_p:
                        paused = not paused
                    elif event.key == pygame.K_r:
                        snake, direction, next_direction, food, score, level, paused = reset_game()
                        level_message_timer = 0
                    elif event.key == pygame.K_x:
                        running = False
                        try:
                            js.eval("window.parent.closeGame && window.parent.closeGame();")
                        except Exception:
                            pass

                    # Movement controls
                    if event.key in (pygame.K_UP, pygame.K_w):
                        if direction != DOWN:
                            next_direction = UP
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        if direction != UP:
                            next_direction = DOWN
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        if direction != RIGHT:
                            next_direction = LEFT
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        if direction != LEFT:
                            next_direction = RIGHT

        # ========================================================
        # STATE: START SCREEN
        # ========================================================
        if game_state == STATE_START:
            draw_background("kitty")
            title = big_font.render("CUTE SNAKE", True, DARK_PINK)
            start_text = font.render("Press SPACE to start", True, BLACK)
            controls = small_font.render("Arrow Keys / WASD  |  P = Pause", True, BLACK)

            screen.blit(title, title.get_rect(center=(SIZE // 2, 230)))
            screen.blit(start_text, start_text.get_rect(center=(SIZE // 2, 330)))
            screen.blit(controls, controls.get_rect(center=(SIZE // 2, 380)))

            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
            continue

        # ========================================================
        # STATE: GAME LOGIC
        # ========================================================
        if game_state == STATE_PLAYING and not paused:
            direction = next_direction
            head_x, head_y = snake[0]
            new_head = (head_x + direction[0], head_y + direction[1])

            # Wall or self collision -> Game Over
            if (new_head[0] < 0 or new_head[0] >= GRID or
                new_head[1] < 0 or new_head[1] >= GRID or
                new_head in snake):
                game_state = STATE_GAMEOVER
                player_name = ""
                lb_submitted = False
                lb_error = ""
                lb_loading = True
                fetch_leaderboard_js()
            else:
                snake.insert(0, new_head)
                if new_head == food:
                    score += 1
                    old_level = level
                    level = score + 1
                    if score > high_score:
                        high_score = score
                    food = create_food(snake)
                    if level != old_level:
                        level_message_timer = pygame.time.get_ticks() + 1000
                else:
                    snake.pop()

        if game_state == STATE_GAMEOVER:
            poll_js_results()

        # ========================================================
        # DRAWING & UI
        # ========================================================
        theme = get_theme(level)
        colors = get_theme_colors(theme)

        draw_background(theme)
        food_type = get_food_type(level)
        draw_food(food, food_type, colors["food"])
        draw_snake(snake, theme)

        # Standard HUD
        text_color = WHITE if theme == "space" else BLACK
        score_text = font.render(f"Score: {score}", True, text_color)
        best_text = small_font.render(f"Best: {high_score}", True, text_color)
        screen.blit(score_text, (10, 10))
        screen.blit(best_text, (SIZE - 90, 12))

        # Level up message
        if pygame.time.get_ticks() < level_message_timer:
            level_up = font.render(f"LEVEL {level}!", True, colors["snake"])
            message_rect = level_up.get_rect(center=(SIZE // 2, 80))
            message_bg = message_rect.inflate(24, 16)
            pygame.draw.rect(screen, colors["background"], message_bg, border_radius=12)
            screen.blit(level_up, level_up.get_rect(center=message_bg.center))

        # Paused overlay
        if paused and game_state == STATE_PLAYING:
            pause_text = big_font.render("PAUSED", True, YELLOW)
            screen.blit(pause_text, pause_text.get_rect(center=(SIZE // 2, SIZE // 2)))

        # ========================================================
        # GAME OVER / LEADERBOARD SCREEN
        # ========================================================
        if game_state == STATE_GAMEOVER:
            overlay = pygame.Surface((SIZE, SIZE))
            overlay.set_alpha(200)
            overlay.fill(BLACK)
            screen.blit(overlay, (0, 0))

            game_over_text = big_font.render("GAME OVER", True, RED)
            screen.blit(game_over_text, game_over_text.get_rect(center=(SIZE // 2, 45)))

            final_score = font.render(f"Your score: {score}  (Level {level})", True, WHITE)
            screen.blit(final_score, final_score.get_rect(center=(SIZE // 2, 90)))

            if not lb_submitted:
                prompt = small_font.render("Enter your name (Enter to submit):", True, (200, 200, 200))
                screen.blit(prompt, prompt.get_rect(center=(SIZE // 2, 125)))

                box_w, box_h = 260, 34
                box_x = (SIZE - box_w) // 2
                box_y = 140
                pygame.draw.rect(screen, (40, 40, 40), (box_x, box_y, box_w, box_h))
                pygame.draw.rect(screen, WHITE, (box_x, box_y, box_w, box_h), 2)
                nametext = font.render(player_name + ("|" if (pygame.time.get_ticks() // 500) % 2 == 0 else ""), True, WHITE)
                screen.blit(nametext, (box_x + 8, box_y + 4))

                if lb_error:
                    errtext = small_font.render(f"Error: {lb_error}", True, (255, 100, 100))
                    screen.blit(errtext, errtext.get_rect(center=(SIZE // 2, 185)))
            else:
                oktext = small_font.render("Score submitted successfully!", True, (100, 255, 100))
                screen.blit(oktext, oktext.get_rect(center=(SIZE // 2, 155)))

            lb_title = small_font.render("Top 10 Leaderboard", True, (255, 255, 200))
            screen.blit(lb_title, lb_title.get_rect(center=(SIZE // 2, 210)))

            if lb_loading:
                loadtext = small_font.render("Loading scores...", True, (180, 180, 180))
                screen.blit(loadtext, loadtext.get_rect(center=(SIZE // 2, 240)))
            else:
                y_pos = 232
                for i, row in enumerate(leaderboard[:10]):
                    line = f"{i+1}. {row['player_name']} - {row['score']}"
                    linetext = small_font.render(line, True, (220, 220, 220))
                    screen.blit(linetext, ((SIZE - linetext.get_width()) // 2, y_pos))
                    y_pos += 22

            hint = small_font.render("Press R to restart  |  Press X to quit", True, (180, 180, 180))
            screen.blit(hint, hint.get_rect(center=(SIZE // 2, SIZE - 25)))

        pygame.display.flip()

        # Speed scaling based on level
        speed = min(15, 5 + level * 0.5)
        clock.tick(speed)
        await asyncio.sleep(0) # allows browser loop to breathe

    pygame.quit()

asyncio.run(main())