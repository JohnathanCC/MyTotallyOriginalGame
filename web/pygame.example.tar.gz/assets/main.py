import pygame 
import random 
import asyncio #Web browsers require an asynchronous event loop so the tab doesn't freeze.
#python -m pygbag .
import js # ADDED: Pygbag provides js module for browser interop
API_BASE = "https://my-leaderboard-worker.my-leaderboard-worker.workers.dev" # ADDED: Worker URL

pygame.init()
#setup
font = pygame.font.SysFont(None, 36)
smallfont = pygame.font.SysFont(None, 24) # ADDED: smaller font for leaderboard text
squaresize = 32 #individual pixel count of squares; st 32
levels = [
    [
        "### ###########",
        " P............ ",
        "#.##.##......##",
        "#..........#.##",
        "#.##.##....#..#",
        "#.......C###..#",
        "### ###########"
    ], 
    [
        "### ###########",
        " P..#.......#. ",
        "###.#.#####.#.#",
        "#...#...B...#.#",
        "#.#####.#####.#",
        "#.............#",
        "### ###########"
    ],
    [
        "### ###########",
        " P..#...#...A. ",
        "#.#####.#.###.#",
        "#...#.......#.#",
        "#.###.#.#####.#",
        "......#....... ",
        "### ###########"
    ],
    [
        "### ###########",
        " P....###..... ",
        "###.#######.###",
        "#.............#",
        "###.#######.###",
        "......###..D.. ",
        "### ###########"
    ],
    [
        "### ###########",
        " P............ ",
        "##.###.###.####",
        "#......A......#",
        "##.###.###.####",
        ".............. ",
        "### ###########"
    ],
    [
        "### ###########",
        " P..#...#...C. ",
        "#.#.#.#.#.#.#.#",
        "#.............#",
        "#.#B#.#.#.#.#.#",
        "....#...#..... ",
        "### ###########"
    ],
    [
        "### ###########",
        " P.....#...... ",
        "#.###..#.###.##",
        "#...#..D.#...##",
        "#.###..#.###.##",
        ".C.....#...... ",
        "### ###########"
    ],
    [
        "### ###########",
        " P............ ",
        "#.##.##.##.##.#",
        "#.D.........B.#",
        "#.##.##.##.##.#",
        ".............. ",
        "### ###########"
    ],
    [
        "### ###########",
        " P....###....A ",
        "##.##.###.##.##",
        "#.............#",
        "##.##.###.##.##",
        ".B....###..... ",
        "### ###########"
    ],
    [
        "### ###########",
        ".P.............",
        "#######.#######",
        ".......D.......",
        "#######.#######",
        "..........C....",
        "### ###########"
    ]
]


#ogmap=pmap.copy()#if wanted to make multiple levels would probably change this to currentmap and just make all maps the ogmaps
#charcaters not changing; fixed; convert string array pmap to 2d array of characters to be able to change them
#pmap = [list(row) for row in levels[0]] 
#rows = len(pmap)
#cols = len(pmap[0])
#screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))#fitting x and y via squaresize and mapsize
pygame.display.set_caption("This is my very original game")
mapindex = 0 #starting map index
pmap = []
ogmap = []
rows = len(levels[0])
cols = len(levels[0][0])
xposgrid = 0
yposgrid = 0
#ghostx = 0
#ghosty = 0
ghosts = []
prevgosdir = (0,0)
screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

# ADDED: ---- Leaderboard state ----
STATE_PLAYING = "playing"
STATE_GAMEOVER = "gameover"
game_state = STATE_PLAYING
player_name = ""
leaderboard = []          # list of dicts: {"player_name":..., "score":...}
lb_loading = False
lb_submitted = False
lb_error = ""

def fetch_leaderboard_js(): # ADDED: GET /scores, store result in JS global
    """Ask JS to GET /scores and store the result in window.__lb_data."""
    js.eval(f"""
        window.__lb_data = null;
        window.__lb_error = null;
        fetch('{API_BASE}/scores')
          .then(r => r.json())
          .then(d => {{ window.__lb_data = d; }})
          .catch(e => {{ window.__lb_error = String(e); }});
    """)

def submit_score_js(name, sc): # ADDED: POST /score, store success in JS global
    """Ask JS to POST /score and store success flag in window.__lb_submitted."""
    safe_name = name.replace("\\", "\\\\").replace("'", "\\'")
    js.eval(f"""
        window.__lb_submitted = null;
        fetch('{API_BASE}/score', {{
            method: 'POST',
            headers: {{ 'Content-Type': 'application/json' }},
            body: JSON.stringify({{ name: '{safe_name}', score: {sc} }})
        }})
        .then(r => r.json())
        .then(d => {{ window.__lb_submitted = d.success === true; }})
        .catch(e => {{ window.__lb_submitted = false; }});
    """)

def poll_js_results(): # ADDED: read JS globals each frame
    """Read the JS globals set by the fetch callbacks."""
    global leaderboard, lb_loading, lb_submitted, lb_error
    try:
        data = js.window.__lb_data
        if data is not None:
            # js objects -> Python list of dicts
            leaderboard = [
                {"player_name": str(row["player_name"]), "score": int(row["score"])}
                for row in data
            ]
            lb_loading = False
            js.eval("window.__lb_data = null;")
    except Exception:
        pass

    try:
        err = js.window.__lb_error
        if err is not None:
            lb_error = str(err)
            lb_loading = False
            js.eval("window.__lb_error = null;")
    except Exception:
        pass

    try:
        sub = js.window.__lb_submitted
        if sub is not None:
            lb_submitted = bool(sub)
            js.eval("window.__lb_submitted = null;")
            # refresh leaderboard after a successful submit
            lb_loading = True
            fetch_leaderboard_js()
    except Exception:
        pass

def reset_game(): # ADDED: shared restart logic used by R key in both states
    global gameover, score, direction, nextdirection, ghosts, timer, ghosttimer, mapindex
    gameover = False
    score = 0
    direction = (0, 0)
    nextdirection = (0, 0)
    ghosts = []
    timer = 0
    ghosttimer = 0
    mapindex = 0
    loadlevel()

def loadlevel():
    global pmap, ogmap, mapindex, rows, cols, xposgrid, yposgrid, ghosts#, ghostx, ghosty#, screen
    mapindex = mapindex % len(levels) #copilot filled

    ogmap= levels[mapindex].copy()
    pmap = [list(row) for row in ogmap] 
    rows = len(pmap)
    cols = len(pmap[0])
    ghosts = []
    #screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

    for y in range(rows):
        for x in range(cols):
            if pmap[y][x] == "P":
                xposgrid = x
                yposgrid = y
                pmap[y][x] = " "
            elif pmap[y][x] in ["A","B","C","D"]:
                ghosts.append({
                    "x": x,
                    "y": y,
                    "dir": (-1, 0),
                    "type": pmap[y][x]})
                #ghostx = x
                #ghosty = y
                pmap[y][x] = "."

loadlevel() #initial load
#movement 
direction = (0,0)
nextdirection =(0, 0)
#ghostdir=(-1, 0)

delay = 0.15
timer = 0
ghostdelay = 0.30
ghosttimer = 0
clock = pygame.time.Clock()
running = True
score = 0
gameover = False
            
async def main():
    global xposgrid, yposgrid, pmap, direction, nextdirection#, ghostdir, ghostx, ghosty,
    global timer, ghosttimer, running, score, gameover, mapindex, ogmap, ghosts, prevghosdir
    global game_state, player_name, leaderboard, lb_loading, lb_submitted, lb_error # ADDED: allow reassignment

    while running:
        delta_time = clock.tick(60) / 1000 #how long did it take to call since the last frame (limit to 60 a sec)
                                           #divide by 1000 to convert from milliceconds to seconds
        timer += delta_time #add the time between each frame that sum is the timer
        ghosttimer += delta_time

        #events first
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN: #KEYDOWN is key event, the event.key is the same name as the "pygame.key.get_pressed()" name
                if event.key == pygame.K_ESCAPE: # ADDED: split escape from movement, was combined with X
                    running = False
                    try: # ADDED: platform is not imported; use JS parent call instead
                        js.eval("window.parent.closeGame && window.parent.closeGame();")
                    except Exception:
                        pass
                elif game_state == STATE_PLAYING and not gameover: # ADDED: only movement keys during play
                    if event.key == pygame.K_x:
                        running = False
                        try: # ADDED: same JS close fix
                            js.eval("window.parent.closeGame && window.parent.closeGame();")
                        except Exception:
                            pass
                    elif event.key == pygame.K_UP:
                        nextdirection = (0, -1) #grid pos x y, negative for pygame screen up pos for pygame screen down
                    elif event.key == pygame.K_DOWN:
                        nextdirection = (0, 1)
                    elif event.key == pygame.K_LEFT:
                        nextdirection = (-1, 0)
                    elif event.key == pygame.K_RIGHT:
                        nextdirection = (1, 0)
                    elif event.key == pygame.K_r: 
                        reset_game() # ADDED: use shared reset
                elif game_state == STATE_GAMEOVER: # ADDED: name entry + submit + restart
                    if event.key == pygame.K_BACKSPACE:
                        player_name = player_name[:-1]
                    elif event.key == pygame.K_RETURN:
                        if player_name.strip() and not lb_submitted:
                            submit_score_js(player_name.strip()[:16], score)
                    elif event.key == pygame.K_r and (lb_submitted or not player_name):
                        reset_game()
                        game_state = STATE_PLAYING
                        player_name = ""
                        leaderboard = []
                        lb_loading = False
                        lb_submitted = False
                        lb_error = ""
                    elif event.unicode.isprintable() and len(player_name) < 16:
                        player_name += event.unicode

        if game_state == STATE_PLAYING and not gameover: # ADDED: gate movement/ghost logic on state
            #movement logic
            if timer >= delay: #same concept as snake, delay is at 0.15
                timer = 0

                #change current direction
                #lookx = xposgrid + nextdirection[0]
                #looky = yposgrid + nextdirection[1]
                #if not pmap[looky][lookx] == "#":
                direction = nextdirection

                #current direction move forward
                nextx= xposgrid+direction[0] #0 and 1 as in x and y of nextdirection
                nexty= yposgrid+direction[1]
                nextx=nextx%cols # -1%3=2
                nexty=nexty%rows

                if not pmap[nexty][nextx] == "#":#if your next position is not a wall then move to it
                
                    xposgrid = nextx
                    yposgrid = nexty
                
                    #if that new pos is pellet, collect
                    if pmap[nexty][nextx] == ".":#row col is y x
                        pmap[nexty][nextx] = " "
                        score += 1
                        if not any("." in row for row in pmap) and score > 0: 
                            mapindex += 1
                            if mapindex >= len(levels):
                                mapindex = 0
                            loadlevel()
                            #pmap = [list(row) for row in ogmap] #rebuild map from orriginal
                
                else: #dont move if the next pos is a wall
                    direction = (0, 0)


            #ghost logic
            if ghosttimer >= ghostdelay: #same concept as pac delay just longer
                ghosttimer = 0
                for ghost in ghosts:
                    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)] #up down left right
                    choices = [] #empty

                    for direcx, direcy in directions: #look the four
                        #ghostlookx = ghostx + direcx
                        #ghostlooky = ghosty + direcy
                        ghostlookx = ghost["x"] + direcx
                        ghostlooky = ghost["y"] + direcy

                        ghostlookx = ghostlookx % cols
                        ghostlooky = ghostlooky % rows
                    
                        if pmap[ghostlooky][ghostlookx] != "#": #check possible directions to move
                            choices.append((direcx, direcy))

                    if choices:
                        currentGhostDir = ghost["dir"]
                        oppositeDir = (-currentGhostDir[0], -currentGhostDir[1])

                        nonReverseChoices = [d for d in choices if d != oppositeDir]
                        if nonReverseChoices:
                            availableChoices = nonReverseChoices
                        else:
                            availableChoices = choices
                        #availableChoices = choices

                        if ghost["type"] == "A":
                            chasedir = availableChoices[0]
                            mindist = ((cols*squaresize) * (rows*squaresize))
                            for c in availableChoices:
                                nextghostx = (ghost["x"] + c[0]) % cols
                                nextghosty = (ghost["y"] + c[1]) % rows
                                dist = abs(nextghostx - xposgrid) + abs(nextghosty - yposgrid)
                                if dist < mindist:
                                    mindist = dist
                                    chasedir = c
                            ghost["dir"] = chasedir

                        elif ghost["type"] == "B":
                            prevghosdir = ghost["dir"]
                            ghost["dir"] = random.choice(availableChoices) #random.choice(list)
                            while (ghost["dir"][0] == -prevghosdir[0] and ghost["dir"][1] == -prevghosdir[1]) and len(availableChoices) > 1:
                                ghost["dir"] = random.choice(availableChoices)

                        elif ghost["type"] == "C":
                            chasedir = availableChoices[0]
                            maxdist = 0
                            for c in availableChoices:
                                nextghostx = (ghost["x"] + c[0]) % cols
                                nextghosty = (ghost["y"] + c[1]) % rows
                                dist = abs(nextghostx - xposgrid) + abs(nextghosty - yposgrid)
                                if dist > maxdist:
                                    maxdist = dist
                                    chasedir = c
                            ghost["dir"] = chasedir

                        elif ghost["type"] == "D":
                            nextghostx = xposgrid
                            nextghosty = yposgrid
                            for i in range(3):
                                if(pmap[nextghosty][nextghostx] != '#'):                                
                                    nextghostx = (nextghostx + direction[0]) %cols
                                    nextghosty = (nextghosty + direction[1]) %rows
                                ghosttargetx=nextghostx
                                ghosttargety=nextghosty

                            chasedir = availableChoices[0]
                            mindist = ((cols*squaresize) * (rows*squaresize))
                            for c in availableChoices:
                                nextghostx = (ghost["x"] + c[0]) % cols
                                nextghosty = (ghost["y"] + c[1]) % rows
                                dist = abs(nextghostx - ghosttargetx) + abs(nextghosty - ghosttargety)
                                if dist < mindist:
                                    mindist = dist
                                    chasedir = c
                            ghost["dir"] = chasedir



                    #ghost["x"] = (ghost["x"] + ghost["dir"][0]) % cols
                    #ghost["y"] = (ghost["y"] + ghost["dir"][1]) % rows
                    if pmap[(ghost["y"] + ghost["dir"][1]) % rows][(ghost["x"] + ghost["dir"][0]) % cols] != "#":
                        ghost["x"] = (ghost["x"] + ghost["dir"][0]) % cols
                        ghost["y"] =(ghost["y"] + ghost["dir"][1]) % rows




        #if xposgrid == ghostx and yposgrid == ghosty: #if they same loc then gameover
        #    #print("Game over")
        #    gameover = True
        if game_state == STATE_PLAYING: # ADDED: collision check only during play
            for ghost in ghosts:
                if (ghost["x"] == xposgrid and ghost["y"] == yposgrid):
                    gameover = True
            if gameover: # ADDED: transition to gameover screen + start fetch
                game_state = STATE_GAMEOVER
                player_name = ""
                lb_submitted = False
                lb_error = ""
                lb_loading = True
                fetch_leaderboard_js()

        if game_state == STATE_GAMEOVER: # ADDED: poll async JS results each frame
            poll_js_results()


        screen.fill((0, 0, 0)) #black background

        if game_state == STATE_PLAYING: # ADDED: original draw block only during play
            #map draw
            for y in range(rows):
                for x in range(cols):
                    xpospix= x * squaresize
                    ypospix= y * squaresize
                    tile = pmap[y][x] #draw map tiles one after new position changes
                    if tile == "#": #wall draw
                        pygame.draw.rect(screen, (0, 0, 220),(xpospix, ypospix, squaresize, squaresize))
                    elif tile == ".": #pellot draw
                        pygame.draw.circle(screen, (255, 255, 255),(xpospix+squaresize // 2,ypospix+ squaresize // 2),3)
                                            #white, (x,y) x half of xpixels+square size//2 to get in the middle

            #pac draw
            centerPacx = xposgrid * squaresize + squaresize // 2
            centerPacy = yposgrid * squaresize + squaresize // 2
            pygame.draw.circle(screen, (255, 255, 0),(centerPacx, centerPacy), squaresize // 2 - 2)
                                #location yellow centercoords leftside
            #ghost draw
            for ghost in ghosts:
                centerGhostx = ghost["x"] * squaresize + squaresize // 2
                centerGhosty = ghost["y"] * squaresize + squaresize // 2
                #centerGhostx = ghostx * squaresize + squaresize // 2
                #centerGhosty = ghosty * squaresize + squaresize // 2
                if ghost["type"] == "A":
                    gcolor = (255, 0, 0)
                elif ghost["type"] == "B":
                    gcolor = (255, 105, 180)  #pink
                elif ghost["type"] == "C":
                    gcolor = (0, 255, 255)    #cyan
                else:
                    gcolor = (255, 165, 0)    #orange

                pygame.draw.circle(screen, gcolor, (centerGhostx, centerGhosty), squaresize // 2 - 2)
                #pygame.draw.circle(screen,(255, 0, 0),(centerGhostx, centerGhosty),squaresize // 2 - 2)


            #score draw
            scoretext = font.render(f"Score: {score}", True, (255, 255, 255)) #the true was for anti aliasing i know for emlation its for quality so im assuming thats the same here like quality of letters
            screen.blit(scoretext, (5,5))

        else: # ADDED: gameover screen with name input + leaderboard
            title = font.render("GAME OVER", True, (255, 0, 0))
            screen.blit(title, ((screen.get_width() - title.get_width()) // 2, 20))

            scoretext = font.render(f"Your score: {score}", True, (255, 255, 255))
            screen.blit(scoretext, ((screen.get_width() - scoretext.get_width()) // 2, 60))

            if not lb_submitted:
                prompt = smallfont.render("Enter your name (Enter to submit):", True, (200, 200, 200))
                screen.blit(prompt, ((screen.get_width() - prompt.get_width()) // 2, 100))

                box_w, box_h = 260, 36 # ADDED: input box
                box_x = (screen.get_width() - box_w) // 2
                box_y = 128
                pygame.draw.rect(screen, (40, 40, 40), (box_x, box_y, box_w, box_h))
                pygame.draw.rect(screen, (255, 255, 255), (box_x, box_y, box_w, box_h), 2)
                nametext = font.render(player_name + ("|" if (pygame.time.get_ticks() // 500) % 2 == 0 else ""), True, (255, 255, 255))
                screen.blit(nametext, (box_x + 8, box_y + 4))

                if lb_error:
                    errtext = smallfont.render(f"Error: {lb_error}", True, (255, 100, 100))
                    screen.blit(errtext, ((screen.get_width() - errtext.get_width()) // 2, 172))
            else:
                oktext = smallfont.render("Score submitted!", True, (100, 255, 100))
                screen.blit(oktext, ((screen.get_width() - oktext.get_width()) // 2, 100))

            lb_title = smallfont.render("Top 10", True, (255, 255, 200))
            screen.blit(lb_title, ((screen.get_width() - lb_title.get_width()) // 2, 200))

            if lb_loading:
                loadtext = smallfont.render("Loading...", True, (180, 180, 180))
                screen.blit(loadtext, ((screen.get_width() - loadtext.get_width()) // 2, 226))
            else:
                y = 226
                for i, row in enumerate(leaderboard[:10]):
                    line = f"{i+1}. {row['player_name']} - {row['score']}"
                    linetext = smallfont.render(line, True, (220, 220, 220))
                    screen.blit(linetext, ((screen.get_width() - linetext.get_width()) // 2, y))
                    y += 24

            hint = smallfont.render("Press R to restart", True, (150, 150, 150))
            screen.blit(hint, ((screen.get_width() - hint.get_width()) // 2, screen.get_height() - 30))


        #display frame
        pygame.display.flip()
        await asyncio.sleep(0)  #allows the browser to breathe
    pygame.quit()
    #try:
    #    import platform
    #    platform.window.location.href = "../index.html"
    #except Exception as e:
    #    print("Redirect failed:", e)
    


asyncio.run(main())