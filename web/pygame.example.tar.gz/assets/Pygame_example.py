import pygame
import random

pygame.init()
#setup
size = 260
screen=pygame.display.set_mode((size,size))
font = pygame.font.SysFont(None, 36)
#sound=pygame.mixer.Sound('')
#sound.play()

squaresize = 32 #32x32 pixel squares
gridsize = size // squaresize


#this area for image loading and transformations
#snake_img = pygame.image.load('snake.png').convert()
#snake_img=pygame.transform.scale(snake_img, (snake_img.get_width()/2,snake_img.get_height()/2))
#snake_img.set_colorkey((0,0,0))
#ogsnake_img=snake_img 
#
running = True

speed=50
delta_time =0.1
counter = 0
clock=pygame.time.Clock()

xposgrid=3
yposgrid=1
snakebody = [(3, 1),(2, 1),(1, 1)]

delay = 0.15
timer = 0
foodx=random.randint(0, gridsize - 1)
foody=random.randint(0, gridsize - 1)
food = pygame.Rect(foodx*squaresize,foody*squaresize,squaresize,squaresize) #was 40,40 need to put in grid
wasonfood=False

while running:
    screen.fill((0,0,0))
    #screen.fill((255,255,255))

    #grid draw
    for xg in range(0, size, squaresize): #0 to 640 every 32 pixels
        pygame.draw.line(screen, (200, 200, 200), (xg, 0), (xg, size)) #drawn from y0 to ysize x increases sqsize each loop
    for yg in range(0, size, squaresize):
        pygame.draw.line(screen, (200, 200, 200), (0, yg), (size, yg)) #same concept as vertical lines, 200,200,200 is grey

    #32p
    #(1,1)=(32,32)     (2,1)=(64,32) 
    #each position movement +- 32 either x or y
    x=squaresize * xposgrid
    y=squaresize * yposgrid




    mpos = pygame.mouse.get_pos() # (x, y)

    # image blitting and htboxes
    #screen.blit(snake_img, (x, y)) #puts loaded image on screen
    #hitbox = pygame.Rect(x,y,snake_img.get_width(), snake_img.get_height()) #make hitbox at the og location of the snake (x,30) set it to snake size
    for part in snakebody:
        partx = part[0] * squaresize
        party = part[1] * squaresize
        pygame.draw.rect(screen,(0, 255, 0),(partx, party, squaresize, squaresize))

    foodx = food.x // squaresize
    foody = food.y // squaresize

    eating = (xposgrid, yposgrid) == (foodx, foody)

    if eating:
        while True:#just reroll if new food in snake
            foodx = random.randint(0, gridsize - 1)
            foody = random.randint(0, gridsize - 1)
            if (foodx, foody) not in snakebody:
                break

        food.x = foodx * squaresize
        food.y = foody * squaresize

        counter += 1

    #colliding = hitbox.colliderect(food)
    #mouse_collision = food.collidepoint(mpos)

    #pygame.draw.rect(screen, (255*colliding, 255*mouse_collision, 0), food)
    pygame.draw.rect(screen, (255, 0, 0), food)

    
    #target=pygame.Rect(300,0,160,280) #parameters x,y,width,height
    #collision = hitbox.colliderect(target) #boolean if snake hitbox collides with target

    #mouse_collision = target.collidepoint(mpos) #collidepoint parameters is an x,y position that mouse.get_pos() returns. returns boolean

    #pygame.draw.rect(screen, (255*collision, 255*mouse_collision,0), target) #collision multiplies R value by 0 when not colliding and 1 if is making target green or yellow
    
    #colliding = hitbox.colliderect(food)
    #if wasonfood and not colliding:
        #food.x = random.randint(0, gridsize-1) * squaresize #min,man
        #food.y = random.randint(0, gridsize-1) * squaresize
        #counter+=1
    #wasonfood = colliding

    #


    #x+=50*delta_time #test object moentent


    



    for event in pygame.event.get():
        #exit event dont touch pls
        if event.type == pygame.QUIT:
            running=False
        #
    keys=pygame.key.get_pressed()
    if keys[pygame.K_x]:#x key to end shortcut
        running=False

    if keys[pygame.K_m]:#reset snake to ypos 300
        yposgrid=gridsize//2
      
    #if keys[pygame.K_u]:#speed up
    #    speed*=1.1
    #if keys[pygame.K_d]:#speed down
    #    speed/=1.1
    

    timer+=delta_time
    if timer>=delay:
        #direction keys
        if keys[pygame.K_DOWN]:
            yposgrid+=1#speed*delta_time
            #snake_img=pygame.transform.rotate(ogsnake_img, 270)#degrees in reference to grid not of the image pos
            eating = (xposgrid, yposgrid) == (food.x // squaresize,food.y // squaresize)
            snakebody.insert(0, (xposgrid, yposgrid))
            if not eating:
                snakebody.pop()
        elif keys[pygame.K_UP]:
            yposgrid-=1#speed*delta_time
            #snake_img=pygame.transform.rotate(ogsnake_img, 90)
            eating = (xposgrid, yposgrid) == (food.x // squaresize,food.y // squaresize)
            snakebody.insert(0, (xposgrid, yposgrid))
            if not eating:
                snakebody.pop()
        elif keys[pygame.K_RIGHT]:         
            xposgrid+=1#speed*delta_time
            #snake_img=pygame.transform.rotate(ogsnake_img, 0)
            eating = (xposgrid, yposgrid) == (food.x // squaresize,food.y // squaresize)
            snakebody.insert(0, (xposgrid, yposgrid))
            if not eating:
                snakebody.pop()
        elif keys[pygame.K_LEFT]:
            xposgrid-=1#speed*delta_time
            #snake_img=pygame.transform.rotate(ogsnake_img, 180)
            eating = (xposgrid, yposgrid) == (food.x // squaresize,food.y // squaresize)
            snakebody.insert(0, (xposgrid, yposgrid))
            if not eating:
                snakebody.pop()
        timer=0
        #move head position by adding new bodypart pop the end one
        

        if (xposgrid < 0 or xposgrid >= gridsize or yposgrid < 0 or yposgrid >= gridsize):
            running = False
        elif (xposgrid, yposgrid) in snakebody[1:]:#if te head is inside the list of snake body parts
            running = False
    


    


    score = font.render(f"{counter}", True, (0, 0, 0))
    screen.blit(score, (size-20, 10))

    pygame.display.flip() #displays the current frame to the screen

    #clock.tick(30)
    delta_time=clock.tick(60) / 1000
    delta_time=max(0.001, min(0.1, delta_time))
    
pygame.quit()