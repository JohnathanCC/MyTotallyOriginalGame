import pygame 
import random 
import asyncio #Web browsers require an asynchronous event loop so the tab doesn't freeze.

pygame.init()
#setup
font = pygame.font.SysFont(None, 36)
squaresize = 32 #individual pixel count of squares; st 32
levels = [
    [
        "### ###########",
        " P............ ",
        "#.##.##......##",
        "#..........#.##",
        "#.##.##....#..#",
        "#.......G###..#",
        "### ###########"
    ], 
    [
        "### ###########",
        " P..#.......#. ",
        "###.#.#####.#.#",
        "#...#...G...#.#",
        "#.#####.#####.#",
        "#.............#",
        "### ###########"
    ],
    # Map 3: Twin Tunnel Crossroad
    [
        "### ###########",
        " P..#...#...G. ",
        "#.#####.#.###.#",
        "#...#.......#.#",
        "#.###.#.#####.#",
        "......#....... ",
        "### ###########"
    ],
    # Map 4: Center Divider
    [
        "### ###########",
        " P....###..... ",
        "###.#######.###",
        "#.......G.....#",
        "###.#######.###",
        "......###..... ",
        "### ###########"
    ],
    # Map 5: The Triple Split
    [
        "### ###########",
        " P............ ",
        "##.###.###.####",
        "#......G......#",
        "##.###.###.####",
        ".............. ",
        "### ###########"
    ],
    # Map 6: Pillars of Doom
    [
        "### ###########",
        " P..#...#...G. ",
        "#.#.#.#.#.#.#.#",
        "#.............#",
        "#.#.#.#.#.#.#.#",
        "....#...#..... ",
        "### ###########"
    ],
    # Map 7: Double Ring
    [
        "### ###########",
        " P.....#...... ",
        "#.###..#.###.##",
        "#...#..G.#...#",
        "#.###..#.###.##",
        ".......#...... ",
        "### ###########"
    ],
    # Map 8: The Checkerboard Blocks
    [
        "### ###########",
        " P............ ",
        "#.##.##.##.##.#",
        "#.....G.......#",
        "#.##.##.##.##.#",
        ".............. ",
        "### ###########"
    ],
    # Map 9: Symmetric Maze
    [
        "### ###########",
        " P....###....G ",
        "##.##.###.##.##",
        "#.............#",
        "##.##.###.##.##",
        "......###..... ",
        "### ###########"
    ],
    # Map 10: Pure Speedways
    [
        "### ###########",
        " P............ ",
        "###############",
        ".......G.......",
        "###############",
        ".............. ",
        "### ###########"
    ]
]


#ogmap=pmap.copy()#if wanted to make multiple levels would probably change this to currentmap and just make all maps the ogmaps
#charcaters not changing; fixed; convert string array pmap to 2d array of characters to be able to change them
#pmap = [list(row) for row in levels[0]] 
#rows = len(pmap)
#cols = len(pmap[0])
#screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))#fitting x and y via squaresize and mapsize
pygame.display.set_caption("This is my very original game")
mapindex = 0
pmap = []
ogmap = []
rows = len(levels[0])
cols = len(levels[0][0])
xposgrid = 0
yposgrid = 0
ghostx = 0
ghosty = 0
screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

def loadlevel(mapindex):
    global pmap, ogmap, rows, cols, xposgrid, yposgrid, ghostx, ghosty, screen, start_x, start_y
    mapindex = mapindex % len(levels) #copilot filled

    ogmap= levels[mapindex].copy()
    pmap = [list(row) for row in ogmap] 
    rows = len(pmap)
    cols = len(pmap[0])
    #screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

    for y in range(rows):
        for x in range(cols):
            if pmap[y][x] == "P":
                xposgrid = x
                yposgrid = y
                start_x = x 
                start_y = y
                pmap[y][x] = " "
            elif pmap[y][x] == "G":
                ghostx = x
                ghosty = y
                pmap[y][x] = " "

loadlevel(5) #initial load
#movement 
direction = (0,0)
nextdirection =(0, 0)
ghostdir=(-1, 0)

delay = 0.15
timer = 0
ghostdelay = 0.30
ghosttimer = 0
clock = pygame.time.Clock()
running = True
score = 0
gameover = False
            
async def main():
    global xposgrid, yposgrid, ghostx, ghosty, pmap, direction, nextdirection, ghostdir
    global timer, ghosttimer, running, score, gameover, mapindex, ogmap, start_x, start_y

    while running:
        delta_time = clock.tick(60) / 1000 #how long did it take to call since the last frame (limit to 60 a sec)
                                           #divide by 1000 to convert from milliceconds to seconds
        timer += delta_time #add the time between each frame that sum is the timer
        ghosttimer += delta_time

        #events first
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN: #KEYDOWN is key event, the event.key is the same name as the "pygame.key.get_pressed()" name
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_x:
                    running = False
                elif event.key == pygame.K_UP:
                    nextdirection = (0, -1) #grid pos x y, negative for pygame screen up pos for pygame screen down
                elif event.key == pygame.K_DOWN:
                    nextdirection = (0, 1)
                elif event.key == pygame.K_LEFT:
                    nextdirection = (-1, 0)
                elif event.key == pygame.K_RIGHT:
                    nextdirection = (1, 0)
                elif event.key == pygame.K_r: 
                    gameover = False
                    score = 0
                    direction = (0, 0)
                    nextdirection = (0, 0)
                    ghostdir = (-1, 0)
                    timer = 0
                    ghosttimer = 0
                    
                    mapindex = 0 
                    loadlevel(mapindex)

        if not gameover:
            #movement logic
            if timer >= delay: #same concept as snake, delay is at 0.15
                timer = 0

                #change current direction
                #lookx = xposgrid + nextdirection[0]
                #looky = yposgrid + nextdirection[1]
                #if not pmap[looky][lookx] == "#":
                direction = nextdirection

                #current direction move forward
                nextx= xposgrid+direction[0] #0 and 1 as in x and y of nextdirection
                nexty= yposgrid+direction[1]
                nextx=nextx%cols # -1%3=2
                nexty=nexty%rows

                if not pmap[nexty][nextx] == "#":#if your next position is not a wall then move to it
                
                    xposgrid = nextx
                    yposgrid = nexty
                
                    #if that new pos is pellet, collect
                    if pmap[nexty][nextx] == ".":#row col is y x
                        pmap[nexty][nextx] = " "
                        score += 1
                        if not any("." in row for row in pmap): 
                            mapindex += 1
                            loadlevel(mapindex)
                            #pmap = [list(row) for row in ogmap] #rebuild map from orriginal
                
                else: #dont move if the next pos is a wall
                    direction = (0, 0)


            #ghost logic
            if ghosttimer >= ghostdelay: #same concept as pac delay just longer
                ghosttimer = 0
                directions = [(0, -1), (0, 1), (-1, 0), (1, 0)] #up down left right
                choices = [] #empty

                for direcx, direcy in directions: #look the four
                    ghostlookx = ghostx + direcx
                    ghostlooky = ghosty + direcy
                    ghostlookx = ghostlookx % cols
                    ghostlooky = ghostlooky % rows

                    if pmap[ghostlooky][ghostlookx] != "#": #check possible directions to move
                        choices.append((direcx, direcy))

                if choices:
                    ghostdir = random.choice(choices) #random.choice(list)
                ghostx = (ghostx + ghostdir[0]) % cols
                ghosty = (ghosty + ghostdir[1]) % rows



        if xposgrid == ghostx and yposgrid == ghosty: #if they same loc then gameover
            #print("Game over")
            gameover = True

        screen.fill((0, 0, 0)) #black background

        #map draw
        for y in range(rows):
            for x in range(cols):
                xpospix= x * squaresize
                ypospix= y * squaresize
                tile = pmap[y][x] #draw map tiles one after new position changes
                if tile == "#": #wall draw
                    pygame.draw.rect(screen, (0, 0, 220),(xpospix, ypospix, squaresize, squaresize))
                elif tile == ".": #pellot draw
                    pygame.draw.circle(screen, (255, 255, 255),(xpospix+squaresize // 2,ypospix+ squaresize // 2),3)
                                        #white, (x,y) x half of xpixels+square size//2 to get in the middle

        #pac draw
        centerPacx = xposgrid * squaresize + squaresize // 2
        centerPacy = yposgrid * squaresize + squaresize // 2
        pygame.draw.circle(screen, (255, 255, 0),(centerPacx, centerPacy), squaresize // 2 - 2)
                            #location yellow centercoords leftside
        #ghost draw
        centerGhostx = ghostx * squaresize + squaresize // 2
        centerGhosty = ghosty * squaresize + squaresize // 2
        pygame.draw.circle(screen,(255, 0, 0),(centerGhostx, centerGhosty),squaresize // 2 - 2)


        #score draw
        scoretext = font.render(f"Score: {score}", True, (255, 255, 255)) #the true was for anti aliasing i know for emlation its for quality so im assuming thats the same here like quality of letters
        screen.blit(scoretext, (5,5))

        #gameover draw
        if gameover:
            gameovertext = font.render("GAME OVER", True, (255, 0, 0))

            textx = (screen.get_width() - gameovertext.get_width()) // 2 
            texty = (screen.get_height() - gameovertext.get_height()) // 2

            screen.blit(gameovertext, (textx, texty))


        #display frame
        pygame.display.flip()
        await asyncio.sleep(0)  # Crucial: allows the browser to breathe
    pygame.quit()
    


asyncio.run(main())