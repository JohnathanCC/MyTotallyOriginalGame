import pygame 
import random 
import asyncio #Web browsers require an asynchronous event loop so the tab doesn't freeze.
#python -m pygbag .

pygame.init()
#setup
font = pygame.font.SysFont(None, 36)
squaresize = 32 #individual pixel count of squares; st 32
levels = [
    [
        "### ###########",
        " P............ ",
        "#.##.##..C...##",
        "#..........#.##",
        "#.##.##....#..#",
        "#........###..#",
        "### ###########"
    ], 
    [
        "### ###########",
        " P..#.......#. ",
        "###.#.#####.#.#",
        "#...#...B...#.#",
        "#.#####.#####.#",
        "#.............#",
        "### ###########"
    ],
    # Map 3: Twin Tunnel Crossroad
    [
        "### ###########",
        " P..#...#...B. ",
        "#.#####.#.###.#",
        "#...#.......#.#",
        "#.###.#.#####.#",
        "......#....... ",
        "### ###########"
    ],
    # Map 4: Center Divider
    [
        "### ###########",
        " P....###..... ",
        "###.#######.###",
        "#.............#",
        "###.#######.###",
        "......###..B.. ",
        "### ###########"
    ],
    # Map 5: The Triple Split
    [
        "### ###########",
        " P............ ",
        "##.###.###.####",
        "#......A......#",
        "##.###.###.####",
        ".............. ",
        "### ###########"
    ],
    # Map 6: Pillars of Doom
    [
        "### ###########",
        " P..#...#...C. ",
        "#.#.#.#.#.#.#.#",
        "#.............#",
        "#.#B#.#.#.#.#.#",
        "....#...#..... ",
        "### ###########"
    ],
    # Map 7: Double Ring
    [
        "### ###########",
        " P.....#...C.. ",
        "#.###..#.###.##",
        "#...#..D.#...#",
        "#.###..#.###.##",
        ".C.....#...... ",
        "### ###########"
    ],
    # Map 8: The Checkerboard Blocks
    [
        "### ###########",
        " P............ ",
        "#.##.##.##.##.#",
        "#.....A.......#",
        "#.##.##.##.##.#",
        ".............. ",
        "### ###########"
    ],
    # Map 9: Symmetric Maze
    [
        "### ###########",
        " P....###....A ",
        "##.##.###.##.##",
        "#.............#",
        "##.##.###.##.##",
        ".B....###..... ",
        "### ###########"
    ],
    # Map 10: Pure Speedways
    [
        "### ###########",
        ".P.............",
        "#######.#######",
        ".......A.......",
        "#######.#######",
        "...............",
        "### ###########"
    ]
]


#ogmap=pmap.copy()#if wanted to make multiple levels would probably change this to currentmap and just make all maps the ogmaps
#charcaters not changing; fixed; convert string array pmap to 2d array of characters to be able to change them
#pmap = [list(row) for row in levels[0]] 
#rows = len(pmap)
#cols = len(pmap[0])
#screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))#fitting x and y via squaresize and mapsize
pygame.display.set_caption("This is my very original game")
mapindex = 0 #starting map index
pmap = []
ogmap = []
rows = len(levels[0])
cols = len(levels[0][0])
xposgrid = 0
yposgrid = 0
#ghostx = 0
#ghosty = 0
ghosts = []
prevgosdir = (0,0)
screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

def loadlevel():
    global pmap, ogmap, mapindex, rows, cols, xposgrid, yposgrid, ghosts#, ghostx, ghosty#, screen
    mapindex = mapindex % len(levels) #copilot filled

    ogmap= levels[mapindex].copy()
    pmap = [list(row) for row in ogmap] 
    rows = len(pmap)
    cols = len(pmap[0])
    ghosts = []
    #screen = pygame.display.set_mode((cols*squaresize, rows*squaresize))

    for y in range(rows):
        for x in range(cols):
            if pmap[y][x] == "P":
                xposgrid = x
                yposgrid = y
                pmap[y][x] = " "
            elif pmap[y][x] in ["A","B","C","D"]:
                ghosts.append({
                    "x": x,
                    "y": y,
                    "dir": (-1, 0),
                    "type": pmap[y][x]})
                #ghostx = x
                #ghosty = y
                pmap[y][x] = "."

loadlevel() #initial load
#movement 
direction = (0,0)
nextdirection =(0, 0)
#ghostdir=(-1, 0)

delay = 0.15
timer = 0
ghostdelay = 0.30
ghosttimer = 0
clock = pygame.time.Clock()
running = True
score = 0
gameover = False
            
async def main():
    global xposgrid, yposgrid, pmap, direction, nextdirection#, ghostdir, ghostx, ghosty,
    global timer, ghosttimer, running, score, gameover, mapindex, ogmap, ghosts, prevghosdir

    while running:
        delta_time = clock.tick(60) / 1000 #how long did it take to call since the last frame (limit to 60 a sec)
                                           #divide by 1000 to convert from milliceconds to seconds
        timer += delta_time #add the time between each frame that sum is the timer
        ghosttimer += delta_time

        #events first
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN: #KEYDOWN is key event, the event.key is the same name as the "pygame.key.get_pressed()" name
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_x:
                    running = False
                elif event.key == pygame.K_UP:
                    nextdirection = (0, -1) #grid pos x y, negative for pygame screen up pos for pygame screen down
                elif event.key == pygame.K_DOWN:
                    nextdirection = (0, 1)
                elif event.key == pygame.K_LEFT:
                    nextdirection = (-1, 0)
                elif event.key == pygame.K_RIGHT:
                    nextdirection = (1, 0)
                elif event.key == pygame.K_r: 
                    gameover = False
                    score = 0
                    direction = (0, 0)
                    nextdirection = (0, 0)
                    #ghostdir = (-1, 0)
                    ghosts = []
                    timer = 0
                    ghosttimer = 0
                    
                    mapindex = 0 
                    loadlevel()

        if not gameover:
            #movement logic
            if timer >= delay: #same concept as snake, delay is at 0.15
                timer = 0

                #change current direction
                #lookx = xposgrid + nextdirection[0]
                #looky = yposgrid + nextdirection[1]
                #if not pmap[looky][lookx] == "#":
                direction = nextdirection

                #current direction move forward
                nextx= xposgrid+direction[0] #0 and 1 as in x and y of nextdirection
                nexty= yposgrid+direction[1]
                nextx=nextx%cols # -1%3=2
                nexty=nexty%rows

                if not pmap[nexty][nextx] == "#":#if your next position is not a wall then move to it
                
                    xposgrid = nextx
                    yposgrid = nexty
                
                    #if that new pos is pellet, collect
                    if pmap[nexty][nextx] == ".":#row col is y x
                        pmap[nexty][nextx] = " "
                        score += 1
                        if not any("." in row for row in pmap) and score > 0: 
                            mapindex += 1
                            if mapindex >= len(levels):
                                mapindex = 0
                            loadlevel()
                            #pmap = [list(row) for row in ogmap] #rebuild map from orriginal
                
                else: #dont move if the next pos is a wall
                    direction = (0, 0)


            #ghost logic
            if ghosttimer >= ghostdelay: #same concept as pac delay just longer
                ghosttimer = 0
                for ghost in ghosts:
                    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)] #up down left right
                    choices = [] #empty

                    for direcx, direcy in directions: #look the four
                        #ghostlookx = ghostx + direcx
                        #ghostlooky = ghosty + direcy
                        ghostlookx = ghost["x"] + direcx
                        ghostlooky = ghost["y"] + direcy

                        ghostlookx = ghostlookx % cols
                        ghostlooky = ghostlooky % rows
                    
                        if pmap[ghostlooky][ghostlookx] != "#": #check possible directions to move
                            choices.append((direcx, direcy))

                    if choices:
                        current_dir = ghost["dir"]
                        opposite_dir = (-current_dir[0], -current_dir[1])
                        non_reverse_choices = [d for d in choices if d != opposite_dir]
                        available_choices = non_reverse_choices if non_reverse_choices else choices

                        if ghost["type"] == "A":
                            chasedir = available_choices[0]
                            mindist = ((cols*squaresize) * (rows*squaresize))
                            for c in available_choices:
                                nextghostx = (ghost["x"] + c[0]) % cols
                                nextghosty = (ghost["y"] + c[1]) % rows
                                dist = abs(nextghostx - xposgrid) + abs(nextghosty - yposgrid)
                                if dist < mindist:
                                    mindist = dist
                                    chasedir = c
                            ghost["dir"] = chasedir

                        elif ghost["type"] == "B":
                            prevghosdir = ghost["dir"]
                            ghost["dir"] = random.choice(available_choices) #random.choice(list)
                            while (ghost["dir"][0] == -prevghosdir[0] and ghost["dir"][1] == -prevghosdir[1]) and len(available_choices) > 1:
                                ghost["dir"] = random.choice(available_choices)

                        elif ghost["type"] == "C":
                            chasedir = available_choices[0]
                            maxdist = 0
                            for c in available_choices:
                                nextghostx = (ghost["x"] + c[0]) % cols
                                nextghosty = (ghost["y"] + c[1]) % rows
                                dist = abs(nextghostx - xposgrid) + abs(nextghosty - yposgrid)
                                if dist > maxdist:
                                    maxdist = dist
                                    chasedir = c
                            ghost["dir"] = chasedir

                        elif ghost["type"] == "D":
                            ghost["dir"] = random.choice(choices) #random.choice(list)

                    #ghost["x"] = (ghost["x"] + ghost["dir"][0]) % cols
                    #ghost["y"] = (ghost["y"] + ghost["dir"][1]) % rows
                    if pmap[(ghost["y"] + ghost["dir"][1]) % rows][(ghost["x"] + ghost["dir"][0]) % cols] != "#":
                        ghost["x"] = (ghost["x"] + ghost["dir"][0]) % cols
                        ghost["y"] =(ghost["y"] + ghost["dir"][1]) % rows




        #if xposgrid == ghostx and yposgrid == ghosty: #if they same loc then gameover
        #    #print("Game over")
        #    gameover = True
        for ghost in ghosts:
            if (ghost["x"] == xposgrid and ghost["y"] == yposgrid):
                gameover = True


        screen.fill((0, 0, 0)) #black background

        #map draw
        for y in range(rows):
            for x in range(cols):
                xpospix= x * squaresize
                ypospix= y * squaresize
                tile = pmap[y][x] #draw map tiles one after new position changes
                if tile == "#": #wall draw
                    pygame.draw.rect(screen, (0, 0, 220),(xpospix, ypospix, squaresize, squaresize))
                elif tile == ".": #pellot draw
                    pygame.draw.circle(screen, (255, 255, 255),(xpospix+squaresize // 2,ypospix+ squaresize // 2),3)
                                        #white, (x,y) x half of xpixels+square size//2 to get in the middle

        #pac draw
        centerPacx = xposgrid * squaresize + squaresize // 2
        centerPacy = yposgrid * squaresize + squaresize // 2
        pygame.draw.circle(screen, (255, 255, 0),(centerPacx, centerPacy), squaresize // 2 - 2)
                            #location yellow centercoords leftside
        #ghost draw
        for ghost in ghosts:
            centerGhostx = ghost["x"] * squaresize + squaresize // 2
            centerGhosty = ghost["y"] * squaresize + squaresize // 2
            #centerGhostx = ghostx * squaresize + squaresize // 2
            #centerGhosty = ghosty * squaresize + squaresize // 2
            if ghost["type"] == "A":
                gcolor = (255, 0, 0)
            elif ghost["type"] == "B":
                gcolor = (255, 105, 180)  #pink
            elif ghost["type"] == "C":
                gcolor = (0, 255, 255)    #cyan
            else:
                gcolor = (255, 165, 0)    #orange

            pygame.draw.circle(screen, gcolor, (centerGhostx, centerGhosty), squaresize // 2 - 2)
            #pygame.draw.circle(screen,(255, 0, 0),(centerGhostx, centerGhosty),squaresize // 2 - 2)


        #score draw
        scoretext = font.render(f"Score: {score}", True, (255, 255, 255)) #the true was for anti aliasing i know for emlation its for quality so im assuming thats the same here like quality of letters
        screen.blit(scoretext, (5,5))

        #gameover draw
        if gameover:
            gameovertext = font.render("GAME OVER", True, (255, 0, 0))

            textx = (screen.get_width() - gameovertext.get_width()) // 2 
            texty = (screen.get_height() - gameovertext.get_height()) // 2

            screen.blit(gameovertext, (textx, texty))


        #display frame
        pygame.display.flip()
        await asyncio.sleep(0)  # Crucial: allows the browser to breathe
    pygame.quit()
    


asyncio.run(main())