import pygame 
import random 
import asyncio # Web browsers require an asynchronous event loop so the tab doesn't freeze.
# python -m pygbag .
import js # ADDED: Pygbag provides js module for browser interop
API_BASE = "https://my-leaderboard-worker.my-leaderboard-worker.workers.dev" # ADDED: Worker URL
GAME_ID = "snake" # ADDED: Game identifier for leaderboard

pygame.init()
# setup
font = pygame.font.SysFont(None, 36)
smallfont = pygame.font.SysFont(None, 24) # ADDED: smaller font for leaderboard text
squaresize = 32 # individual pixel count of squares

# Define grid dimensions (e.g., 20x20 grid)
cols = 20
rows = 20
screen = pygame.display.set_mode((cols * squaresize, rows * squaresize))
pygame.display.set_caption("Cute Snake Leaderboard Game")

# Directions
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

# ADDED: ---- Leaderboard state ----
STATE_PLAYING = "playing"
STATE_GAMEOVER = "gameover"
game_state = STATE_PLAYING
player_name = ""
leaderboard = []         # list of dicts: {"player_name":..., "score":...}
lb_loading = False
lb_submitted = False
lb_error = ""

def fetch_leaderboard_js(): # ADDED: GET /scores, store result in JS global
    """Ask JS to GET /scores and store the result in window.__lb_data."""
    js.eval(f"""
        window.__lb_data = null;
        window.__lb_error = null;
        fetch('{API_BASE}/scores?game={GAME_ID}')
          .then(r => r.json())
          .then(d => {{ window.__lb_data = d; }})
          .catch(e => {{ window.__lb_error = String(e); }});
    """)

def submit_score_js(name, sc): # ADDED: POST /score, store success in JS global
    """Ask JS to POST /score and store success flag in window.__lb_submitted."""
    safe_name = name.replace("\\", "\\\\").replace("'", "\\'")
    js.eval(f"""
        window.__lb_submitted = null;
        fetch('{API_BASE}/score', {{
            method: 'POST',
            headers: {{ 'Content-Type': 'application/json' }},
            body: JSON.stringify({{ game: '{GAME_ID}', name: '{safe_name}', score: {sc} }})
        }})
        .then(r => r.json())
        .then(d => {{ window.__lb_submitted = d.success === true; }})
        .catch(e => {{ window.__lb_submitted = false; }});
    """)

def poll_js_results(): # ADDED: read JS globals each frame
    """Read the JS globals set by the fetch callbacks."""
    global leaderboard, lb_loading, lb_submitted, lb_error
    try:
        data = js.window.__lb_data
        if data is not None:
            leaderboard = [
                {"player_name": str(row["player_name"]), "score": int(row["score"])}
                for row in data
            ]
            lb_loading = False
            js.eval("window.__lb_data = null;")
    except Exception:
        pass

    try:
        err = js.window.__lb_error
        if err is not None:
            lb_error = str(err)
            lb_loading = False
            js.eval("window.__lb_error = null;")
    except Exception:
        pass

    try:
        sub = js.window.__lb_submitted
        if sub is not None:
            lb_submitted = bool(sub)
            js.eval("window.__lb_submitted = null;")
            lb_loading = True
            fetch_leaderboard_js()
    except Exception:
        pass

def create_food(snake):
    while True:
        fx = random.randrange(cols)
        fy = random.randrange(rows)
        if (fx, fy) not in snake:
            return (fx, fy)

def reset_game(): # ADDED: shared restart logic used by R key in both states
    global snake, direction, nextdirection, food, score, gameover, timer
    snake = [(10, 10), (9, 10), (8, 10)]
    direction = RIGHT
    nextdirection = RIGHT
    food = create_food(snake)
    score = 0
    gameover = False
    timer = 0

# Game variables
snake = []
direction = RIGHT
nextdirection = RIGHT
food = (0, 0)
score = 0
gameover = False

delay = 0.15
timer = 0
clock = pygame.time.Clock()
running = True

reset_init_food = reset_game()

async def main():
    global snake, direction, nextdirection, food, timer, running, score, gameover
    global game_state, player_name, leaderboard, lb_loading, lb_submitted, lb_error

    while running:
        delta_time = clock.tick(60) / 1000 # convert from milliseconds to seconds
        timer += delta_time

        # Events first
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                    try:
                        js.eval("window.parent.closeGame && window.parent.closeGame();")
                    except Exception:
                        pass
                elif game_state == STATE_PLAYING and not gameover:
                    if event.key == pygame.K_x:
                        running = False
                        try:
                            js.eval("window.parent.closeGame && window.parent.closeGame();")
                        except Exception:
                            pass
                    elif event.key == pygame.K_UP and direction != DOWN:
                        nextdirection = UP
                    elif event.key == pygame.K_DOWN and direction != UP:
                        nextdirection = DOWN
                    elif event.key == pygame.K_LEFT and direction != RIGHT:
                        nextdirection = LEFT
                    elif event.key == pygame.K_RIGHT and direction != LEFT:
                        nextdirection = RIGHT
                    elif event.key == pygame.K_r: 
                        reset_game()
                elif game_state == STATE_GAMEOVER:
                    if event.key == pygame.K_BACKSPACE:
                        player_name = player_name[:-1]
                    elif event.key == pygame.K_RETURN:
                        if player_name.strip() and not lb_submitted:
                            submit_score_js(player_name.strip()[:16], score)
                    elif event.key == pygame.K_r and (lb_submitted or not player_name):
                        reset_game()
                        game_state = STATE_PLAYING
                        player_name = ""
                        leaderboard = []
                        lb_loading = False
                        lb_submitted = False
                        lb_error = ""
                    elif event.unicode.isprintable() and len(player_name) < 16:
                        player_name += event.unicode

        if game_state == STATE_PLAYING and not gameover:
            # Movement logic updates on delay interval
            if timer >= delay:
                timer = 0
                direction = nextdirection

                head_x, head_y = snake[0]
                new_head = ((head_x + direction[0]) % cols, (head_y + direction[1]) % rows)

                # Self collision check
                if new_head in snake:
                    gameover = True
                else:
                    snake.insert(0, new_head)
                    # Check food collision
                    if new_head == food:
                        score += 1
                        food = create_food(snake)
                    else:
                        snake.pop()

            if gameover:
                game_state = STATE_GAMEOVER
                player_name = ""
                lb_submitted = False
                lb_error = ""
                lb_loading = True
                fetch_leaderboard_js()

        if game_state == STATE_GAMEOVER:
            poll_js_results()

        # Rendering
        screen.fill((25, 25, 25)) # Dark background

        if game_state == STATE_PLAYING:
            # Draw grid / food / snake
            pygame.draw.circle(
                screen, (230, 70, 70), 
                (food[0] * squaresize + squaresize // 2, food[1] * squaresize + squaresize // 2), 
                squaresize // 2 - 3
            )

            for i, segment in enumerate(snake):
                seg_color = (90, 200, 100) if i == 0 else (45, 150, 70)
                rect = pygame.Rect(
                    segment[0] * squaresize + 2, 
                    segment[1] * squaresize + 2, 
                    squaresize - 4, 
                    squaresize - 4
                )
                pygame.draw.rect(screen, seg_color, rect, border_radius=6)

            # Score draw
            scoretext = font.render(f"Score: {score}", True, (255, 255, 255))
            screen.blit(scoretext, (5, 5))

        else: # GAME OVER & LEADERBOARD SCREEN
            title = font.render("GAME OVER", True, (255, 0, 0))
            screen.blit(title, ((screen.get_width() - title.get_width()) // 2, 20))

            scoretext = font.render(f"Your score: {score}", True, (255, 255, 255))
            screen.blit(scoretext, ((screen.get_width() - scoretext.get_width()) // 2, 60))

            if not lb_submitted:
                prompt = smallfont.render("Enter your name (Enter to submit):", True, (200, 200, 200))
                screen.blit(prompt, ((screen.get_width() - prompt.get_width()) // 2, 100))

                box_w, box_h = 260, 36
                box_x = (screen.get_width() - box_w) // 2
                box_y = 128
                pygame.draw.rect(screen, (40, 40, 40), (box_x, box_y, box_w, box_h))
                pygame.draw.rect(screen, (255, 255, 255), (box_x, box_y, box_w, box_h), 2)
                nametext = font.render(player_name + ("|" if (pygame.time.get_ticks() // 500) % 2 == 0 else ""), True, (255, 255, 255))
                screen.blit(nametext, (box_x + 8, box_y + 4))

                if lb_error:
                    errtext = smallfont.render(f"Error: {lb_error}", True, (255, 100, 100))
                    screen.blit(errtext, ((screen.get_width() - errtext.get_width()) // 2, 172))
            else:
                oktext = smallfont.render("Score submitted!", True, (100, 255, 100))
                screen.blit(oktext, ((screen.get_width() - oktext.get_width()) // 2, 100))

            lb_title = smallfont.render("Top 10", True, (255, 255, 200))
            screen.blit(lb_title, ((screen.get_width() - lb_title.get_width()) // 2, 200))

            if lb_loading:
                loadtext = smallfont.render("Loading...", True, (180, 180, 180))
                screen.blit(loadtext, ((screen.get_width() - loadtext.get_width()) // 2, 226))
            else:
                y_pos = 226
                for i, row in enumerate(leaderboard[:10]):
                    line = f"{i+1}. {row['player_name']} - {row['score']}"
                    linetext = smallfont.render(line, True, (220, 220, 220))
                    screen.blit(linetext, ((screen.get_width() - linetext.get_width()) // 2, y_pos))
                    y_pos += 24

            hint = smallfont.render("Press R to restart", True, (150, 150, 150))
            screen.blit(hint, ((screen.get_width() - hint.get_width()) // 2, screen.get_height() - 30))

        # Display frame
        pygame.display.flip()
        await asyncio.sleep(0) # allows the browser to breathe

    pygame.quit()

asyncio.run(main())